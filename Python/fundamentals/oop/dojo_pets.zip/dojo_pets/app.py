from modules import ninja, pet

patel = ninja.Ninja('Pudo', 'Patel', ['biscuits', 'steak'], 'protein', pet.Dog('eyy b0ss', 'canine', 'poop on the bed'))

patel.feed().walk().bathe()